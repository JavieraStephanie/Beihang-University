﻿package TicketDemo;

public class Tickets {
	public int total=100;
	public Tickets() {
		this.total =total ;
	}
    public int getTotal(){
    	return this.total;
    }
}